namespace Ksu.Cis300.HelloWorld
{
    public partial class UserInterface : Form
    {
        public UserInterface()
        {
            InitializeComponent();
        }
    }
}