﻿/* UserInterface.cs
 * Author: Rod Howell
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Ksu.Cis300.StringsAndStringBuilders
{
    /// <summary>
    /// A GUI for a program that tests implementations of strings and StringBuilders.
    /// </summary>
    public partial class UserInterface : Form
    {
        /// <summary>
        /// Constructs the GUI.
        /// </summary>
        public UserInterface()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles a Click event on the "Test String" button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uxTestString_Click(object sender, EventArgs e)
        {
            if (uxOpenDialog.ShowDialog() == DialogResult.OK)
            {
                string text = File.ReadAllText(uxOpenDialog.FileName);
                string result = "";
                for (int i = 0; i < text.Length; i++)
                {
                    char c = text[i];
                    if (Char.IsLower(c))
                    {
                        result += Char.ToUpper(c);
                    }
                    else if (Char.IsUpper(c))
                    {
                        result += Char.ToLower(c);
                    }
                    else
                    {
                        result += c;
                    }
                }
                if (uxSaveDialog.ShowDialog() == DialogResult.OK)
                {
                    File.WriteAllText(uxSaveDialog.FileName, result);
                }
            }
        }

        /// <summary>
        /// Handles a Click event on the "Test StringBuilder" button.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uxTestStringBuilder_Click(object sender, EventArgs e)
        {
            if (uxOpenDialog.ShowDialog() == DialogResult.OK)
            {
                string text = File.ReadAllText(uxOpenDialog.FileName);
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < text.Length; i++)
                {
                    char c = text[i];
                    if (Char.IsLower(c))
                    {
                        sb.Append(Char.ToUpper(c));
                    }
                    else if (Char.IsUpper(c))
                    {
                        sb.Append(Char.ToLower(c));
                    }
                    else
                    {
                        sb.Append(c);
                    }
                }
                string result = sb.ToString();
                if (uxSaveDialog.ShowDialog() == DialogResult.OK)
                {
                    File.WriteAllText(uxSaveDialog.FileName, result);
                }
            }
        }
    }
}
