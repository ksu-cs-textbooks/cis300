﻿namespace Ksu.Cis300.StringsAndStringBuilders
{
    partial class UserInterface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uxTestString = new System.Windows.Forms.Button();
            this.uxTestStringBuilder = new System.Windows.Forms.Button();
            this.uxOpenDialog = new System.Windows.Forms.OpenFileDialog();
            this.uxSaveDialog = new System.Windows.Forms.SaveFileDialog();
            this.SuspendLayout();
            // 
            // uxTestString
            // 
            this.uxTestString.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxTestString.Location = new System.Drawing.Point(12, 12);
            this.uxTestString.Name = "uxTestString";
            this.uxTestString.Size = new System.Drawing.Size(260, 46);
            this.uxTestString.TabIndex = 0;
            this.uxTestString.Text = "Test String";
            this.uxTestString.UseVisualStyleBackColor = true;
            this.uxTestString.Click += new System.EventHandler(this.uxTestString_Click);
            // 
            // uxTestStringBuilder
            // 
            this.uxTestStringBuilder.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxTestStringBuilder.Location = new System.Drawing.Point(12, 64);
            this.uxTestStringBuilder.Name = "uxTestStringBuilder";
            this.uxTestStringBuilder.Size = new System.Drawing.Size(260, 46);
            this.uxTestStringBuilder.TabIndex = 1;
            this.uxTestStringBuilder.Text = "Test StringBuilder";
            this.uxTestStringBuilder.UseVisualStyleBackColor = true;
            this.uxTestStringBuilder.Click += new System.EventHandler(this.uxTestStringBuilder_Click);
            // 
            // uxOpenDialog
            // 
            this.uxOpenDialog.Filter = "Text files|*.txt|All files|*.*";
            // 
            // uxSaveDialog
            // 
            this.uxSaveDialog.Filter = "Text files|*.txt|All files|*.*";
            // 
            // UserInterface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 121);
            this.Controls.Add(this.uxTestStringBuilder);
            this.Controls.Add(this.uxTestString);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "UserInterface";
            this.Text = "String and StringBuilder Tester";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button uxTestString;
        private System.Windows.Forms.Button uxTestStringBuilder;
        private System.Windows.Forms.OpenFileDialog uxOpenDialog;
        private System.Windows.Forms.SaveFileDialog uxSaveDialog;
    }
}

