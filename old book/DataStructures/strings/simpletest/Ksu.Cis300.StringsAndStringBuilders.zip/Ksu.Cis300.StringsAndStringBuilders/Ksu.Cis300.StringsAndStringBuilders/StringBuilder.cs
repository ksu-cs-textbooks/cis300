﻿/* StringBuilder.cs
 * Author: Rod Howell
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ksu.Cis300.StringsAndStringBuilders
{
    /// <summary>
    /// An implementation of a simplified StringBuilder
    /// </summary>
    public class StringBuilder
    {
        /// <summary>
        /// The character in this StringBuilder.
        /// </summary>
        private char[] _characters = new char[100];

        /// <summary>
        /// The number of characters in this StringBuilder.
        /// </summary>
        private int _length = 0;

        /// <summary>
        /// Appends the given character to the end of this StringBuilder.
        /// </summary>
        /// <param name="c">The character to append.</param>
        /// <returns>This StringBuilder.</returns>
        public StringBuilder Append(char c)
        {
            if (_length == _characters.Length)
            {
                char[] chars = new char[2 * _length];
                _characters.CopyTo(chars, 0);
                _characters = chars;
            }
            _characters[_length] = c;
            _length++;
            return this;
        }

        /// <summary>
        /// Converts this StringBuilder to a string.
        /// </summary>
        /// <returns>The string equivalent of this StringBuilder.</returns>
        public override string ToString()
        {
            return new string(_characters, 0, _length);
        }
    }
}
