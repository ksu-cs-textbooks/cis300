﻿namespace Ksu.Cis300.CustomDialogExample
{
    partial class UserInterface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uxNameLabel = new System.Windows.Forms.Label();
            this.uxName = new System.Windows.Forms.TextBox();
            this.uxPhoneNumberLabel = new System.Windows.Forms.Label();
            this.uxPhoneNumber = new System.Windows.Forms.TextBox();
            this.uxSiblingsLabel = new System.Windows.Forms.Label();
            this.uxSiblings = new System.Windows.Forms.TextBox();
            this.uxNew = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // uxNameLabel
            // 
            this.uxNameLabel.AutoSize = true;
            this.uxNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxNameLabel.Location = new System.Drawing.Point(12, 15);
            this.uxNameLabel.Name = "uxNameLabel";
            this.uxNameLabel.Size = new System.Drawing.Size(66, 24);
            this.uxNameLabel.TabIndex = 0;
            this.uxNameLabel.Text = "Name:";
            // 
            // uxName
            // 
            this.uxName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxName.Location = new System.Drawing.Point(84, 12);
            this.uxName.Name = "uxName";
            this.uxName.ReadOnly = true;
            this.uxName.Size = new System.Drawing.Size(278, 29);
            this.uxName.TabIndex = 1;
            // 
            // uxPhoneNumberLabel
            // 
            this.uxPhoneNumberLabel.AutoSize = true;
            this.uxPhoneNumberLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxPhoneNumberLabel.Location = new System.Drawing.Point(12, 50);
            this.uxPhoneNumberLabel.Name = "uxPhoneNumberLabel";
            this.uxPhoneNumberLabel.Size = new System.Drawing.Size(145, 24);
            this.uxPhoneNumberLabel.TabIndex = 2;
            this.uxPhoneNumberLabel.Text = "Phone Number:";
            // 
            // uxPhoneNumber
            // 
            this.uxPhoneNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxPhoneNumber.Location = new System.Drawing.Point(163, 47);
            this.uxPhoneNumber.Name = "uxPhoneNumber";
            this.uxPhoneNumber.ReadOnly = true;
            this.uxPhoneNumber.Size = new System.Drawing.Size(199, 29);
            this.uxPhoneNumber.TabIndex = 3;
            // 
            // uxSiblingsLabel
            // 
            this.uxSiblingsLabel.AutoSize = true;
            this.uxSiblingsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxSiblingsLabel.Location = new System.Drawing.Point(12, 85);
            this.uxSiblingsLabel.Name = "uxSiblingsLabel";
            this.uxSiblingsLabel.Size = new System.Drawing.Size(175, 24);
            this.uxSiblingsLabel.TabIndex = 4;
            this.uxSiblingsLabel.Text = "Number of Siblings:";
            // 
            // uxSiblings
            // 
            this.uxSiblings.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxSiblings.Location = new System.Drawing.Point(193, 82);
            this.uxSiblings.Name = "uxSiblings";
            this.uxSiblings.ReadOnly = true;
            this.uxSiblings.Size = new System.Drawing.Size(169, 29);
            this.uxSiblings.TabIndex = 5;
            // 
            // uxNew
            // 
            this.uxNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxNew.Location = new System.Drawing.Point(16, 117);
            this.uxNew.Name = "uxNew";
            this.uxNew.Size = new System.Drawing.Size(345, 34);
            this.uxNew.TabIndex = 6;
            this.uxNew.Text = "Get New Information";
            this.uxNew.UseVisualStyleBackColor = true;
            this.uxNew.Click += new System.EventHandler(this.uxNew_Click);
            // 
            // UserInterface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(374, 165);
            this.Controls.Add(this.uxNew);
            this.Controls.Add(this.uxSiblings);
            this.Controls.Add(this.uxSiblingsLabel);
            this.Controls.Add(this.uxPhoneNumber);
            this.Controls.Add(this.uxPhoneNumberLabel);
            this.Controls.Add(this.uxName);
            this.Controls.Add(this.uxNameLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "UserInterface";
            this.Text = "Custom Dialog Example";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label uxNameLabel;
        private System.Windows.Forms.TextBox uxName;
        private System.Windows.Forms.Label uxPhoneNumberLabel;
        private System.Windows.Forms.TextBox uxPhoneNumber;
        private System.Windows.Forms.Label uxSiblingsLabel;
        private System.Windows.Forms.TextBox uxSiblings;
        private System.Windows.Forms.Button uxNew;
    }
}

