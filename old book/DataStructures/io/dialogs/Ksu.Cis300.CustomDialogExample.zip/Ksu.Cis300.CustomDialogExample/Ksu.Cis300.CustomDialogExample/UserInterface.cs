﻿/* UserInterface.cs
 * Author: Rod Howell
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ksu.Cis300.CustomDialogExample
{
    /// <summary>
    /// A user interface for a program demonstrating a custom dialog.
    /// </summary>
    public partial class UserInterface : Form
    {
        /// <summary>
        /// The dialog for obtaining information from the user.
        /// </summary>
        private InformationDialog uxInformation = new InformationDialog();

        /// <summary>
        /// Constructs the GUI.
        /// </summary>
        public UserInterface()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles a Get New Information event.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uxNew_Click(object sender, EventArgs e)
        {
            if (uxInformation.ShowDialog() == DialogResult.OK)
            {
                uxName.Text = uxInformation.FullName;
                uxPhoneNumber.Text = uxInformation.PhoneNumber;
                uxSiblings.Text = uxInformation.Siblings.ToString();
            }
        }
    }
}
