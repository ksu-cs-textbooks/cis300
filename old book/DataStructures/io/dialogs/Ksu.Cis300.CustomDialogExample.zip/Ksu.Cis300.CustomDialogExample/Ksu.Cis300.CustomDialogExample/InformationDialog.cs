﻿/* InformationDialog.cs
 * Author: Rod Howell
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ksu.Cis300.CustomDialogExample
{
    /// <summary>
    /// A dialog for obtaining a name, phone number, and number of siblings.
    /// </summary>
    public partial class InformationDialog : Form
    {
        /// <summary>
        /// Constructs the dialog.
        /// </summary>
        public InformationDialog()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Gets the name.  (There is already a Name property inherited from
        /// the Form class, so we will use FullName.)
        /// </summary>
        public string FullName
        {
            get
            {
                return uxName.Text;
            }
        }

        /// <summary>
        /// Gets the phone number.
        /// </summary>
        public string PhoneNumber
        {
            get
            {
                return uxPhoneNumber.Text;
            }
        }

        /// <summary>
        /// Gets the number of siblings.
        /// </summary>
        public int Siblings
        {
            get
            {
                return (int)uxSiblings.Value;
            }
        }
    }
}
