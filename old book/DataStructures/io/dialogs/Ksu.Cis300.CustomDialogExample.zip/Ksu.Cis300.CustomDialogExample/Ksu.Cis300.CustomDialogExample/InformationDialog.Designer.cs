﻿namespace Ksu.Cis300.CustomDialogExample
{
    partial class InformationDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uxSiblingsLabel = new System.Windows.Forms.Label();
            this.uxPhoneNumber = new System.Windows.Forms.TextBox();
            this.uxPhoneNumberLabel = new System.Windows.Forms.Label();
            this.uxName = new System.Windows.Forms.TextBox();
            this.uxNameLabel = new System.Windows.Forms.Label();
            this.uxSiblings = new System.Windows.Forms.NumericUpDown();
            this.uxOK = new System.Windows.Forms.Button();
            this.uxCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.uxSiblings)).BeginInit();
            this.SuspendLayout();
            // 
            // uxSiblingsLabel
            // 
            this.uxSiblingsLabel.AutoSize = true;
            this.uxSiblingsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxSiblingsLabel.Location = new System.Drawing.Point(10, 84);
            this.uxSiblingsLabel.Name = "uxSiblingsLabel";
            this.uxSiblingsLabel.Size = new System.Drawing.Size(175, 24);
            this.uxSiblingsLabel.TabIndex = 10;
            this.uxSiblingsLabel.Text = "Number of Siblings:";
            // 
            // uxPhoneNumber
            // 
            this.uxPhoneNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxPhoneNumber.Location = new System.Drawing.Point(161, 47);
            this.uxPhoneNumber.Name = "uxPhoneNumber";
            this.uxPhoneNumber.Size = new System.Drawing.Size(199, 29);
            this.uxPhoneNumber.TabIndex = 9;
            // 
            // uxPhoneNumberLabel
            // 
            this.uxPhoneNumberLabel.AutoSize = true;
            this.uxPhoneNumberLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxPhoneNumberLabel.Location = new System.Drawing.Point(10, 50);
            this.uxPhoneNumberLabel.Name = "uxPhoneNumberLabel";
            this.uxPhoneNumberLabel.Size = new System.Drawing.Size(145, 24);
            this.uxPhoneNumberLabel.TabIndex = 8;
            this.uxPhoneNumberLabel.Text = "Phone Number:";
            // 
            // uxName
            // 
            this.uxName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxName.Location = new System.Drawing.Point(82, 12);
            this.uxName.Name = "uxName";
            this.uxName.Size = new System.Drawing.Size(278, 29);
            this.uxName.TabIndex = 7;
            // 
            // uxNameLabel
            // 
            this.uxNameLabel.AutoSize = true;
            this.uxNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxNameLabel.Location = new System.Drawing.Point(10, 15);
            this.uxNameLabel.Name = "uxNameLabel";
            this.uxNameLabel.Size = new System.Drawing.Size(66, 24);
            this.uxNameLabel.TabIndex = 6;
            this.uxNameLabel.Text = "Name:";
            // 
            // uxSiblings
            // 
            this.uxSiblings.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxSiblings.Location = new System.Drawing.Point(199, 82);
            this.uxSiblings.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.uxSiblings.Name = "uxSiblings";
            this.uxSiblings.Size = new System.Drawing.Size(161, 29);
            this.uxSiblings.TabIndex = 11;
            this.uxSiblings.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // uxOK
            // 
            this.uxOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.uxOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxOK.Location = new System.Drawing.Point(14, 117);
            this.uxOK.Name = "uxOK";
            this.uxOK.Size = new System.Drawing.Size(171, 34);
            this.uxOK.TabIndex = 12;
            this.uxOK.Text = "OK";
            this.uxOK.UseVisualStyleBackColor = true;
            // 
            // uxCancel
            // 
            this.uxCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.uxCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxCancel.Location = new System.Drawing.Point(191, 117);
            this.uxCancel.Name = "uxCancel";
            this.uxCancel.Size = new System.Drawing.Size(171, 34);
            this.uxCancel.TabIndex = 13;
            this.uxCancel.Text = "Cancel";
            this.uxCancel.UseVisualStyleBackColor = true;
            // 
            // InformationDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(373, 165);
            this.Controls.Add(this.uxCancel);
            this.Controls.Add(this.uxOK);
            this.Controls.Add(this.uxSiblings);
            this.Controls.Add(this.uxSiblingsLabel);
            this.Controls.Add(this.uxPhoneNumber);
            this.Controls.Add(this.uxPhoneNumberLabel);
            this.Controls.Add(this.uxName);
            this.Controls.Add(this.uxNameLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "InformationDialog";
            this.Text = "Enter Information";
            ((System.ComponentModel.ISupportInitialize)(this.uxSiblings)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label uxSiblingsLabel;
        private System.Windows.Forms.TextBox uxPhoneNumber;
        private System.Windows.Forms.Label uxPhoneNumberLabel;
        private System.Windows.Forms.TextBox uxName;
        private System.Windows.Forms.Label uxNameLabel;
        private System.Windows.Forms.NumericUpDown uxSiblings;
        private System.Windows.Forms.Button uxOK;
        private System.Windows.Forms.Button uxCancel;

    }
}