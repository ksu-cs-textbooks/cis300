﻿namespace Ksu.Cis300.HelloWorld
{
    partial class UserInterface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uxDisplay = new System.Windows.Forms.TextBox();
            this.uxGo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // uxDisplay
            // 
            this.uxDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxDisplay.Location = new System.Drawing.Point(12, 12);
            this.uxDisplay.Name = "uxDisplay";
            this.uxDisplay.ReadOnly = true;
            this.uxDisplay.Size = new System.Drawing.Size(260, 26);
            this.uxDisplay.TabIndex = 0;
            // 
            // uxGo
            // 
            this.uxGo.Location = new System.Drawing.Point(12, 44);
            this.uxGo.Name = "uxGo";
            this.uxGo.Size = new System.Drawing.Size(260, 27);
            this.uxGo.TabIndex = 1;
            this.uxGo.Text = "Go";
            this.uxGo.UseVisualStyleBackColor = true;
            this.uxGo.Click += new System.EventHandler(this.uxGo_Click);
            // 
            // UserInterface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 85);
            this.Controls.Add(this.uxGo);
            this.Controls.Add(this.uxDisplay);
            this.Name = "UserInterface";
            this.Text = "Hello";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox uxDisplay;
        private System.Windows.Forms.Button uxGo;
    }
}

