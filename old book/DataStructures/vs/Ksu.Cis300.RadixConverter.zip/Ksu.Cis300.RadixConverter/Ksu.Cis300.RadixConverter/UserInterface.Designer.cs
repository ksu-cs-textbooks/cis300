﻿namespace Ksu.Cis300.RadixConverter
{
    partial class UserInterface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uxOutput = new System.Windows.Forms.TextBox();
            this.uxConvert = new System.Windows.Forms.Button();
            this.uxInput = new System.Windows.Forms.NumericUpDown();
            this.uxInputLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.uxInput)).BeginInit();
            this.SuspendLayout();
            // 
            // uxOutput
            // 
            this.uxOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxOutput.Location = new System.Drawing.Point(177, 49);
            this.uxOutput.Name = "uxOutput";
            this.uxOutput.ReadOnly = true;
            this.uxOutput.Size = new System.Drawing.Size(307, 29);
            this.uxOutput.TabIndex = 7;
            this.uxOutput.Text = "0";
            this.uxOutput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // uxConvert
            // 
            this.uxConvert.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxConvert.Location = new System.Drawing.Point(17, 44);
            this.uxConvert.Name = "uxConvert";
            this.uxConvert.Size = new System.Drawing.Size(154, 40);
            this.uxConvert.TabIndex = 6;
            this.uxConvert.Text = "Convert to Hex:";
            this.uxConvert.UseVisualStyleBackColor = true;
            this.uxConvert.Click += new System.EventHandler(this.uxConvert_Click);
            // 
            // uxInput
            // 
            this.uxInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxInput.Location = new System.Drawing.Point(177, 14);
            this.uxInput.Maximum = new decimal(new int[] {
            -1,
            -1,
            -1,
            0});
            this.uxInput.Name = "uxInput";
            this.uxInput.Size = new System.Drawing.Size(322, 29);
            this.uxInput.TabIndex = 5;
            this.uxInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // uxInputLabel
            // 
            this.uxInputLabel.AutoSize = true;
            this.uxInputLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxInputLabel.Location = new System.Drawing.Point(15, 16);
            this.uxInputLabel.Name = "uxInputLabel";
            this.uxInputLabel.Size = new System.Drawing.Size(156, 24);
            this.uxInputLabel.TabIndex = 4;
            this.uxInputLabel.Text = "Base 10 Number:";
            // 
            // UserInterface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(514, 98);
            this.Controls.Add(this.uxOutput);
            this.Controls.Add(this.uxConvert);
            this.Controls.Add(this.uxInput);
            this.Controls.Add(this.uxInputLabel);
            this.Name = "UserInterface";
            this.Text = "Radix Converter";
            ((System.ComponentModel.ISupportInitialize)(this.uxInput)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox uxOutput;
        private System.Windows.Forms.Button uxConvert;
        private System.Windows.Forms.NumericUpDown uxInput;
        private System.Windows.Forms.Label uxInputLabel;
    }
}

