﻿/* UserInterface.cs
 * Author: Rod Howell */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ksu.Cis300.RadixConverter
{
    /// <summary>
    /// A GUI for a program that converts decimal to hexadecimal.
    /// </summary>
    public partial class UserInterface : Form
    {
        /// <summary>
        /// Constructs the GUI.
        /// </summary>
        public UserInterface()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles a Click event on the Convert button.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uxConvert_Click(object sender, EventArgs e)
        {
            uxOutput.Text = ConvertToHex(uxInput.Value);
        }

        /// <summary>
        /// Converts the given decimal value to its equivalent hex string.
        /// </summary>
        /// <param name="baseTenNumber">The number to be converted.</param>
        /// <returns>The equivalent hex string.</returns>
        private string ConvertToHex(decimal baseTenNumber)
        {
            if (baseTenNumber < 10)
            {
                /* We can just use the single digit as the string. */
                return baseTenNumber.ToString();
            }
            else if (baseTenNumber < 16)
            {
                /* We need a single hex digit, obtained by going a certain number of values past
                 * 'A' in the Unicode sequence. */
                return ((char)('A' + baseTenNumber - 10)).ToString();
            }
            else
            {
                decimal divisor = 16; /* A power of 16 that we will divide by to break up the number. */
                int power = 1; /* The power to which 16 is raised to obtain divisor. */
                /* We want to find a divisor that breaks the number roughly in half. We do this by squaring
                 * the divisor as many times as we can without exceeding baseTenNumber. Because squaring 16
                 * to the 16th power results in overflow, we will stop if we reach this value. */
                while (power < 16 && divisor * divisor <= baseTenNumber)
                {
                    divisor = divisor * divisor;
                    power = power * 2; /* 16^i * 16^i = 16^(2i) */
                }
                /* We get the high-order part by dividing by divisor, truncating the result, and recursively
                 * converting it to hex. */
                string highOrder = ConvertToHex(Decimal.Truncate(baseTenNumber / divisor));
                /* We get the low-order part by taking the remainder of the above division and recursively
                 * converting it to hex. */
                string lowOrder = ConvertToHex(baseTenNumber % divisor);
                /* Because divisor is no greater than baseTenNumber, the high-order part is always at least 1.
                 * The low-order part may need to be padded with 0s. The number of hex digits needed in the
                 * low-order part is the value of power. */
                string padding = "0000000000000000".Substring(0, lowOrder.Length - power);
                return highOrder + padding + lowOrder;
            }
        }
    }
}
